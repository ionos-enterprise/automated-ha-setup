#!/bin/bash

# Georg Schieche-Dirik
# Script to setup a VDC with two VM's in VRRP-HA-mode
# and a management host for further constructions

# This script is work in progress. And as in general: use at your own risk!
# The hosts to be created need further maintenance as any other host as well.
# License GPL3

if [ $# -le "1" ] ; then
  echo "Usage: `echo $0` -l location [-d] [-D] [-M] [-s] [-i] [-f filesystem] [-S number]"
  echo
  echo "Location can be fra (Frankfurt), fkb (Karlsruhe), ewr (Newark) and las (Las Vegas)"
  echo
  echo "-d activate debug mode"
  echo "-D install the database cluster"
  echo "-M install the MusicBrainz database"
  echo "   The filesystem for the DB would be expanded to at least 300 GB"
  echo "-s use SSD for database volumes"
  echo "-i use Intel for database VM cores"
  echo "-f filesystem"
  echo "   The filesystem could be ext4 (default), xfs, btrfs, zfs"
  echo "-S size of database volume in GB"
  echo
  echo "Just \"`echo $0` -l location\" installs only the gateway HA setup with the management host behind it."
  echo
  echo "The user credentials need to be placed in a file named ${HOME}/ionos/.config in the form 'user@domain.tdl:password' (without apostrophes)."
  echo
  echo "With the \"-d\" option, your Data Center Designer password will be shown on the console!"
  echo

  exit 

fi  

if [[ "$(ssh-add -l)" =~ "no identities" ]] ; then echo "Please load your ssh-key by an agent!" ; exit 2 ; fi
if ! /bin/which pwgen > /dev/null ; then echo "Install pwgen!" ; exit 2 ; fi
if ! /bin/which tee > /dev/null ; then echo "Install tee!" ; exit 2 ; fi
if ! test -e ~/ionos/.config 2>&1 > /dev/null ; then echo "Put your credentials in the file ${HOME}/ionos/.config in the form user@domain.tdl:password" ; exit 2 ; fi

User=$(cat ~/ionos/.config) 

DebugMode=""
ExpectLogUser="log_user 0"
AvoidOutput="2>&1 > /dev/null"
Description="Api-VDC"
StorageType=HDD
cpuFamily=AMD_OPTERON
FileSystem=ext4
DBVolume=20

while getopts "isMDl:df:S:" Option; do
  case $Option in
    d)  DebugMode="set -x"
        ExpectLogUser="log_user 1"
        AvoidOutput=""
        ;;
    l)  Place=$OPTARG
        ;;
    D)  DB=yes
        ;;
    s)  StorageType=SSD
        ;;
    i)  cpuFamily=INTEL_XEON
        ;;
    S)  DBVolume=$OPTARG
        ;;
    f)  FileSystem=$OPTARG
        FileSystem=$(echo ${FileSystem} | tr '[:upper:]' '[:lower:]')
        ;;
    M)  MusicBrainz=yes
        DB=yes
        ;;
    *)  echo "Missing correct option, try $0 to get help"
        exit 2
        ;;
  esac
done

if [[ "${DBVolume}" -lt "300" ]] && [[ "${MusicBrainz}" == "yes" ]] ; then DBVolume=300 ; fi

VDCName="HA_Setup_${Place}_$(date +%F_%H-%M-%S)"

$DebugMode

if [ "$Place" == "fra" ] || [ "$Place" == "fkb" ] ; then
    Country=de
elif [ "$Place" == "las" ] || [ "$Place" == "ewr" ] ; then
    Country=us 
else
    echo "$Place is not a usable place!"
    exit 2
fi

umask 066

MyIP=$(curl -s http://ipecho.net/plain)

if ! echo $MyIP | grep -E '^[0-9]{1,3}(\.[0-9]{1,3}){3}$' > /dev/null ; then
    echo "Service for getting own public IP does not work, please check!" 
    exit 2 
fi

Credentials=~/${VDCName}_credentials.txt
touch $Credentials
source sources/HA-GateAndDatbase_source.sh

echo 
echo "Starting to create the VDC $VDCName including a VRRP high availability setup."
echo "This will take about 30 minutes."

if [ "$DB" == "yes" ] ; then echo "The installation and configuration of the warm standby database cluster with PostgreSQL and PGPool will take nearly 20 minutes." ; fi
if [ "$MusicBrainz" == "yes" ] ; then echo "Filling the database as background task with the example database MusicBrainz will take around five hours." ; fi
echo 
echo "(Several 'Resource does not exist' message will arise. This only means that the programm is waiting for itmes to be created.)"
echo 

###
### Start creating virtual data center
###

echo 
echo Creating VDC $VDCName
echo You will find all the newly created passwords in $Credentials
echo "Root password $PersistendPassword" >> $Credentials

IPBlock=$(SetIPBlock)
XX=( $(echo $IPBlock) ) # Converting variable $IPBLock directly to array only works on commandline, not in script
IPBlock=( $(echo ${XX[*]}) )

echo "IP's ${IPBlock[*]}"

SetDNS

VirtualDC=$( CreateVDC )
PublicLanID=$( CreatePublicLan $VirtualDC )

# Create network gateway segment. Ressources needed: 2 cores, 2 GB Ram, 12 GB storage, 3 crips
# Gateway neighbour lan 10.99.2.0
echo "Creating gateways."
ImageID=$(GetSource Debian-8)


Volume=$(CreateVolume 6 Gateway1 $ImageID $VirtualDC) 
HostID1=$(CreateHost Gateway $Volume ZONE_1 $VirtualDC) 
NicID=$(AddPublicNic $HostID1 $PublicLanID ${IPBlock[0]} $VirtualDC)
NicID=$(AddIPPublicNic $HostID1 $PublicLanID ${IPBlock[0]} ${IPBlock[2]} $NicID $VirtualDC)
CreateIPFailover $PublicLanID $NicID ${IPBlock[2]} $VirtualDC
while ! ping -c 1 -W 2 ${IPBlock[0]} ; do sleep 11 ; done
echo
echo "=>> Host ${IPBlock[0]} up and to be prepared. <<="
echo

Volume=$(CreateVolume 6 Gateway2 $ImageID $VirtualDC) 
HostID2=$(CreateHost Gateway $Volume ZONE_2 $VirtualDC) 
NicID=$(AddPublicNic $HostID2 $PublicLanID ${IPBlock[1]} $VirtualDC)
NicID=$(AddIPPublicNic $HostID2 $PublicLanID ${IPBlock[1]} ${IPBlock[2]} $NicID $VirtualDC)
while ! ping -c 1 -W 2 ${IPBlock[1]} ; do sleep 11 ; done
echo
echo "=>> Host ${IPBlock[1]} up and to be prepared. <<="
echo

PartnerLanID=$(CreateInternalLan Gateways $VirtualDC )
PartnerLanNic=$(AddInternalNic $HostID1 $PartnerLanID ${GatewayPartnerLan}.1 $VirtualDC)
PartnerLanNic=$(AddInternalNic $HostID2 $PartnerLanID ${GatewayPartnerLan}.2 $VirtualDC)

ProductiveLanID=$(CreateInternalLan Productive $VirtualDC )
ProductiveLanNic=$(AddInternalNic $HostID1 $ProductiveLanID ${ProductiveLan}.1 $VirtualDC)
ProductiveLanNic=$(AddInternalNic $HostID2 $ProductiveLanID ${ProductiveLan}.2 $VirtualDC)

echo
echo "Creating management host."
echo
ImageID=$(GetSource Ubuntu-16.04)
Volume=$(CreateVolume 25 Management $ImageID $VirtualDC) 
HostManagement=$(CreateHost Managementserver $Volume AUTO $VirtualDC) 
ManagementLanID=$(CreateInternalLan Management $VirtualDC )
ManagementLanNic=$(AddInternalNic $HostManagement $ManagementLanID ${ManagementLan}.1 $VirtualDC)
ManagementLanNic=$(AddInternalNic $HostID1 $ManagementLanID ${ManagementLan}.2 $VirtualDC)
ManagementLanNic=$(AddInternalNic $HostID2 $ManagementLanID ${ManagementLan}.3 $VirtualDC)

echo "Preparing VRRP configuration."
PrepareGateAgent ${IPBlock[0]} GatewayZONE1 ${IPBlock[2]} ${ManagementLanVirtIP}
PrepareGateAgent ${IPBlock[1]} GatewayZONE2 ${IPBlock[2]} ${ManagementLanVirtIP}

echo "Preparing management host."
PrepareManagementHost 

if [[ "$DB" == "yes" ]] ; then PostgresCluster ; fi

echo "VRRP password $AuthPassVRRP" >> $Credentials
echo "Postgresql replication user 'repuser' password $PWrepuser" >> $Credentials
echo "Postgresql user 'postgres' password $PWpostgres" >> $Credentials
echo "PGPool user 'pgpool' password $PWpgpool" >> $Credentials

echo
echo "Public IPs in use are ${IPBlock[0]}, ${IPBlock[1]} and ${IPBlock[2]}" | tee -a $Credentials
echo "External virtual IP is ${IPBlock[2]}" | tee -a $Credentials
echo
echo "Hosts rebooting now. Be aware that it could take _some minutes_ until the hosts are reachable."
echo
echo "To reach management host direcly try " | tee -a $Credentials
echo "ssh -p 22222 root@${IPBlock[2]}" | tee -a $Credentials
echo
echo "If you want to proceed with a failover test try for example"
echo 
echo "while true ; do ssh -A -p 22222 -o ConnectTimeout=1 root@${IPBlock[2]} "hostname" ; date +%R:%S ; sleep 1 ; done"
echo 
echo "and make a reset via DCD. You should see not more then two occasions with two timeouts until the VRRP master comes back."

if [[ "$DB" == "yes" ]] ; then 
echo "

For accessing the PostgreSQL HA setup some port forwardings are necessary to tunnel connection through ssh.
Port 25432 is used to forward the ssh connection to the database servers and standard port 22 behind the firewal.

ssh -L 33333:127.0.0.1:9999 -p 25432 root@${IPBlock[2]}
For example to create a new database execute: 'createdb -h 127.0.0.1 -p 33333 -U postgres new-database'
(If you import MusicBrainz, you need to wait until this is finished or use another template then template1.)

ssh -L 33334:127.0.0.1:5000 -p 25432 root@${IPBlock[2]}
To access the MusicBrainz web site and web service, go to: http://127.0.0.1:33334

" | tee -a $Credentials
fi

#ssh -L 33335:127.0.0.1:8080 -p 25432 root@${IPBlock[2]}
#To access the Search Server web service, go to: http://127.0.0.1:33335
#
#ssh -L 33336:127.0.0.1:9898 -p 25432 root@${IPBlock[2]}
#To access the PGPool web interface go to: http://127.0.0.1:33336


